
import React from "react";
import { View, Text, StyleSheet, ScrollView, Platform, Pressable } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { IconSymbol } from "@/components/IconSymbol";
import { colors } from "@/styles/commonStyles";

export default function ProfileScreen() {
  return (
    <SafeAreaView style={styles.safeArea} edges={['top']}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={[
          styles.contentContainer,
          Platform.OS !== 'ios' && styles.contentContainerWithTabBar
        ]}
        showsVerticalScrollIndicator={false}
      >
        {/* Profile Header */}
        <View style={styles.profileHeader}>
          <View style={styles.avatarContainer}>
            <IconSymbol name="person.fill" size={60} color={colors.primary} />
          </View>
          <Text style={styles.name}>Mohammed Al-Rashid</Text>
          <Text style={styles.email}>mohammed.rashid@email.com</Text>
          <View style={styles.ratingContainer}>
            <IconSymbol name="star.fill" size={20} color={colors.accent} />
            <Text style={styles.ratingText}>4.8</Text>
            <Text style={styles.ratingLabel}>Passenger Rating</Text>
          </View>
        </View>

        {/* Stats */}
        <View style={styles.statsContainer}>
          <View style={styles.statCard}>
            <Text style={styles.statValue}>47</Text>
            <Text style={styles.statLabel}>Total Trips</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statValue}>AED 1,240</Text>
            <Text style={styles.statLabel}>Total Saved</Text>
          </View>
        </View>

        {/* Personal Information */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Personal Information</Text>
          <View style={styles.infoCard}>
            <View style={styles.infoRow}>
              <IconSymbol name="phone.fill" size={20} color={colors.textSecondary} />
              <View style={styles.infoContent}>
                <Text style={styles.infoLabel}>Phone Number</Text>
                <Text style={styles.infoText}>+971 50 123 4567</Text>
              </View>
            </View>
            <View style={styles.divider} />
            <View style={styles.infoRow}>
              <IconSymbol name="location.fill" size={20} color={colors.textSecondary} />
              <View style={styles.infoContent}>
                <Text style={styles.infoLabel}>Home Location</Text>
                <Text style={styles.infoText}>Dubai Marina, Dubai</Text>
              </View>
            </View>
            <View style={styles.divider} />
            <View style={styles.infoRow}>
              <IconSymbol name="briefcase.fill" size={20} color={colors.textSecondary} />
              <View style={styles.infoContent}>
                <Text style={styles.infoLabel}>Work Location</Text>
                <Text style={styles.infoText}>Business Bay, Dubai</Text>
              </View>
            </View>
          </View>
        </View>

        {/* Payment Methods */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Payment Methods</Text>
          <View style={styles.infoCard}>
            <View style={styles.infoRow}>
              <IconSymbol name="creditcard.fill" size={20} color={colors.primary} />
              <View style={styles.infoContent}>
                <Text style={styles.infoText}>Visa •••• 4242</Text>
                <Text style={styles.infoLabel}>Expires 12/25</Text>
              </View>
              <View style={styles.defaultBadge}>
                <Text style={styles.defaultBadgeText}>Default</Text>
              </View>
            </View>
            <View style={styles.divider} />
            <Pressable style={styles.addButton}>
              <IconSymbol name="plus.circle.fill" size={20} color={colors.primary} />
              <Text style={styles.addButtonText}>Add Payment Method</Text>
            </Pressable>
          </View>
        </View>

        {/* Ride History */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Recent Trips</Text>
          <View style={styles.tripCard}>
            <View style={styles.tripHeader}>
              <View style={styles.tripIconContainer}>
                <IconSymbol name="car.fill" size={24} color={colors.primary} />
              </View>
              <View style={styles.tripInfo}>
                <Text style={styles.tripRoute}>Dubai Mall → JBR Beach</Text>
                <Text style={styles.tripDate}>Dec 15, 2024 • 3:45 PM</Text>
              </View>
              <Text style={styles.tripPrice}>AED 45</Text>
            </View>
          </View>
          <View style={styles.tripCard}>
            <View style={styles.tripHeader}>
              <View style={styles.tripIconContainer}>
                <IconSymbol name="car.fill" size={24} color={colors.primary} />
              </View>
              <View style={styles.tripInfo}>
                <Text style={styles.tripRoute}>Airport → Marina</Text>
                <Text style={styles.tripDate}>Dec 10, 2024 • 8:20 AM</Text>
              </View>
              <Text style={styles.tripPrice}>AED 120</Text>
            </View>
          </View>
          <View style={styles.tripCard}>
            <View style={styles.tripHeader}>
              <View style={styles.tripIconContainer}>
                <IconSymbol name="car.fill" size={24} color={colors.primary} />
              </View>
              <View style={styles.tripInfo}>
                <Text style={styles.tripRoute}>Business Bay → Mall of Emirates</Text>
                <Text style={styles.tripDate}>Dec 8, 2024 • 6:15 PM</Text>
              </View>
              <Text style={styles.tripPrice}>AED 38</Text>
            </View>
          </View>
        </View>

        {/* Settings */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Settings</Text>
          <View style={styles.infoCard}>
            <Pressable style={styles.settingRow}>
              <IconSymbol name="bell.fill" size={20} color={colors.textSecondary} />
              <Text style={styles.settingText}>Notifications</Text>
              <IconSymbol name="chevron.right" size={20} color={colors.textSecondary} />
            </Pressable>
            <View style={styles.divider} />
            <Pressable style={styles.settingRow}>
              <IconSymbol name="lock.fill" size={20} color={colors.textSecondary} />
              <Text style={styles.settingText}>Privacy & Security</Text>
              <IconSymbol name="chevron.right" size={20} color={colors.textSecondary} />
            </Pressable>
            <View style={styles.divider} />
            <Pressable style={styles.settingRow}>
              <IconSymbol name="questionmark.circle.fill" size={20} color={colors.textSecondary} />
              <Text style={styles.settingText}>Help & Support</Text>
              <IconSymbol name="chevron.right" size={20} color={colors.textSecondary} />
            </Pressable>
            <View style={styles.divider} />
            <Pressable style={styles.settingRow}>
              <IconSymbol name="info.circle.fill" size={20} color={colors.textSecondary} />
              <Text style={styles.settingText}>About</Text>
              <IconSymbol name="chevron.right" size={20} color={colors.textSecondary} />
            </Pressable>
          </View>
        </View>

        {/* Logout Button */}
        <Pressable style={styles.logoutButton}>
          <IconSymbol name="arrow.right.square.fill" size={20} color="#FFFFFF" />
          <Text style={styles.logoutButtonText}>Sign Out</Text>
        </Pressable>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.background,
  },
  container: {
    flex: 1,
  },
  contentContainer: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 20,
  },
  contentContainerWithTabBar: {
    paddingBottom: 100,
  },
  profileHeader: {
    alignItems: 'center',
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 24,
    marginBottom: 20,
    boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.08)',
    elevation: 4,
  },
  avatarContainer: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: colors.highlight,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  name: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 4,
  },
  email: {
    fontSize: 16,
    color: colors.textSecondary,
    marginBottom: 12,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.highlight,
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
  },
  ratingText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.text,
    marginLeft: 6,
    marginRight: 8,
  },
  ratingLabel: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  statsContainer: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 20,
  },
  statCard: {
    flex: 1,
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 20,
    alignItems: 'center',
    boxShadow: '0px 2px 8px rgba(0, 0, 0, 0.06)',
    elevation: 2,
  },
  statValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.primary,
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 14,
    color: colors.textSecondary,
    textAlign: 'center',
  },
  section: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 12,
  },
  infoCard: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    boxShadow: '0px 2px 8px rgba(0, 0, 0, 0.06)',
    elevation: 2,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
  },
  infoContent: {
    flex: 1,
    marginLeft: 12,
  },
  infoLabel: {
    fontSize: 12,
    color: colors.textSecondary,
    marginBottom: 2,
  },
  infoText: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
  },
  divider: {
    height: 1,
    backgroundColor: colors.highlight,
    marginVertical: 12,
  },
  defaultBadge: {
    backgroundColor: colors.primary,
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
  },
  defaultBadgeText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  addButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
  },
  addButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.primary,
    marginLeft: 8,
  },
  tripCard: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    boxShadow: '0px 2px 8px rgba(0, 0, 0, 0.06)',
    elevation: 2,
  },
  tripHeader: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  tripIconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: colors.highlight,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  tripInfo: {
    flex: 1,
  },
  tripRoute: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 4,
  },
  tripDate: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  tripPrice: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.primary,
  },
  settingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
  },
  settingText: {
    flex: 1,
    fontSize: 16,
    fontWeight: '500',
    color: colors.text,
    marginLeft: 12,
  },
  logoutButton: {
    backgroundColor: colors.secondary,
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 20,
    marginBottom: 20,
  },
  logoutButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
    marginLeft: 8,
  },
});
