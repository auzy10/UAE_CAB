
import React, { useState } from "react";
import { Stack, useRouter } from "expo-router";
import { 
  ScrollView, 
  Pressable, 
  StyleSheet, 
  View, 
  Text, 
  TextInput,
  Platform,
  Alert
} from "react-native";
import { IconSymbol } from "@/components/IconSymbol";
import { SafeAreaView } from "react-native-safe-area-context";
import { colors } from "@/styles/commonStyles";

const UAE_EMIRATES = [
  "Abu Dhabi",
  "Dubai",
  "Sharjah",
  "Ajman",
  "Umm Al Quwain",
  "Ras Al Khaimah",
  "Fujairah"
];

export default function HomeScreen() {
  const router = useRouter();
  const [pickupLocation, setPickupLocation] = useState("");
  const [dropoffLocation, setDropoffLocation] = useState("");
  const [selectedEmirate, setSelectedEmirate] = useState("");

  const handleSearchRide = () => {
    if (!pickupLocation || !dropoffLocation) {
      Alert.alert("Missing Information", "Please enter both pickup and drop-off locations");
      return;
    }
    
    console.log("Searching for ride:", { pickupLocation, dropoffLocation, selectedEmirate });
    router.push({
      pathname: "/(tabs)/(home)/ride-options",
      params: { 
        pickup: pickupLocation, 
        dropoff: dropoffLocation,
        emirate: selectedEmirate 
      }
    });
  };

  const renderHeaderRight = () => (
    <Pressable
      onPress={() => Alert.alert("Notifications", "No new notifications")}
      style={styles.headerButtonContainer}
    >
      <IconSymbol name="bell.fill" color={colors.primary} size={24} />
    </Pressable>
  );

  return (
    <>
      {Platform.OS === 'ios' && (
        <Stack.Screen
          options={{
            title: "UAE Cab Share",
            headerRight: renderHeaderRight,
          }}
        />
      )}
      <SafeAreaView style={styles.safeArea} edges={['top']}>
        <ScrollView 
          style={styles.container}
          contentContainerStyle={[
            styles.contentContainer,
            Platform.OS !== 'ios' && styles.contentContainerWithTabBar
          ]}
          showsVerticalScrollIndicator={false}
        >
          {/* Header Section */}
          <View style={styles.header}>
            <Text style={styles.headerTitle}>Where to?</Text>
            <Text style={styles.headerSubtitle}>Share your ride across UAE</Text>
          </View>

          {/* Map Placeholder */}
          <View style={styles.mapPlaceholder}>
            <IconSymbol name="map.fill" size={60} color={colors.primary} />
            <Text style={styles.mapPlaceholderText}>
              Map view not available
            </Text>
            <Text style={styles.mapPlaceholderSubtext}>
              react-native-maps is not supported in Natively
            </Text>
          </View>

          {/* Location Input Card */}
          <View style={styles.locationCard}>
            <Text style={styles.cardTitle}>Plan Your Journey</Text>
            
            {/* Emirate Selection */}
            <View style={styles.inputGroup}>
              <IconSymbol name="location.fill" size={20} color={colors.primary} />
              <View style={styles.inputWrapper}>
                <Text style={styles.inputLabel}>Select Emirate</Text>
                <ScrollView 
                  horizontal 
                  showsHorizontalScrollIndicator={false}
                  style={styles.emirateScroll}
                >
                  {UAE_EMIRATES.map((emirate) => (
                    <Pressable
                      key={emirate}
                      style={[
                        styles.emirateChip,
                        selectedEmirate === emirate && styles.emirateChipSelected
                      ]}
                      onPress={() => setSelectedEmirate(emirate)}
                    >
                      <Text style={[
                        styles.emirateChipText,
                        selectedEmirate === emirate && styles.emirateChipTextSelected
                      ]}>
                        {emirate}
                      </Text>
                    </Pressable>
                  ))}
                </ScrollView>
              </View>
            </View>

            {/* Pickup Location */}
            <View style={styles.inputGroup}>
              <View style={styles.locationDot} />
              <View style={styles.inputWrapper}>
                <Text style={styles.inputLabel}>Pickup Location</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Enter pickup address"
                  placeholderTextColor={colors.textSecondary}
                  value={pickupLocation}
                  onChangeText={setPickupLocation}
                />
              </View>
            </View>

            {/* Vertical Line */}
            <View style={styles.verticalLine} />

            {/* Dropoff Location */}
            <View style={styles.inputGroup}>
              <View style={styles.locationSquare} />
              <View style={styles.inputWrapper}>
                <Text style={styles.inputLabel}>Drop-off Location</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Enter destination"
                  placeholderTextColor={colors.textSecondary}
                  value={dropoffLocation}
                  onChangeText={setDropoffLocation}
                />
              </View>
            </View>

            {/* Search Button */}
            <Pressable 
              style={styles.searchButton}
              onPress={handleSearchRide}
            >
              <Text style={styles.searchButtonText}>Search Rides</Text>
              <IconSymbol name="arrow.right" size={20} color="#FFFFFF" />
            </Pressable>
          </View>

          {/* Quick Actions */}
          <View style={styles.quickActions}>
            <Text style={styles.sectionTitle}>Quick Actions</Text>
            <View style={styles.quickActionsGrid}>
              <Pressable style={styles.quickActionCard}>
                <IconSymbol name="clock.fill" size={32} color={colors.accent} />
                <Text style={styles.quickActionText}>Schedule</Text>
              </Pressable>
              <Pressable style={styles.quickActionCard}>
                <IconSymbol name="star.fill" size={32} color={colors.accent} />
                <Text style={styles.quickActionText}>Favorites</Text>
              </Pressable>
              <Pressable style={styles.quickActionCard}>
                <IconSymbol name="person.2.fill" size={32} color={colors.accent} />
                <Text style={styles.quickActionText}>Share Ride</Text>
              </Pressable>
            </View>
          </View>

          {/* Recent Trips */}
          <View style={styles.recentSection}>
            <Text style={styles.sectionTitle}>Recent Trips</Text>
            <View style={styles.recentTrip}>
              <View style={styles.recentTripIcon}>
                <IconSymbol name="car.fill" size={24} color={colors.primary} />
              </View>
              <View style={styles.recentTripDetails}>
                <Text style={styles.recentTripTitle}>Dubai Mall to JBR Beach</Text>
                <Text style={styles.recentTripSubtitle}>2 days ago • AED 45</Text>
              </View>
              <IconSymbol name="arrow.right" size={20} color={colors.textSecondary} />
            </View>
            <View style={styles.recentTrip}>
              <View style={styles.recentTripIcon}>
                <IconSymbol name="car.fill" size={24} color={colors.primary} />
              </View>
              <View style={styles.recentTripDetails}>
                <Text style={styles.recentTripTitle}>Abu Dhabi Airport to Marina</Text>
                <Text style={styles.recentTripSubtitle}>5 days ago • AED 120</Text>
              </View>
              <IconSymbol name="arrow.right" size={20} color={colors.textSecondary} />
            </View>
          </View>
        </ScrollView>
      </SafeAreaView>
    </>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.background,
  },
  container: {
    flex: 1,
  },
  contentContainer: {
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  contentContainerWithTabBar: {
    paddingBottom: 100,
  },
  header: {
    marginTop: 20,
    marginBottom: 20,
  },
  headerTitle: {
    fontSize: 32,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 16,
    color: colors.textSecondary,
  },
  headerButtonContainer: {
    padding: 8,
  },
  mapPlaceholder: {
    backgroundColor: colors.highlight,
    borderRadius: 16,
    height: 200,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
    borderWidth: 2,
    borderColor: colors.primary,
    borderStyle: 'dashed',
  },
  mapPlaceholderText: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
    marginTop: 12,
  },
  mapPlaceholderSubtext: {
    fontSize: 12,
    color: colors.textSecondary,
    marginTop: 4,
  },
  locationCard: {
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
    boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.08)',
    elevation: 4,
  },
  cardTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 20,
  },
  inputGroup: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  inputWrapper: {
    flex: 1,
    marginLeft: 12,
  },
  inputLabel: {
    fontSize: 12,
    fontWeight: '600',
    color: colors.textSecondary,
    marginBottom: 8,
    textTransform: 'uppercase',
  },
  input: {
    backgroundColor: colors.highlight,
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    color: colors.text,
  },
  locationDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: colors.primary,
    marginTop: 28,
  },
  locationSquare: {
    width: 12,
    height: 12,
    backgroundColor: colors.accent,
    marginTop: 28,
  },
  verticalLine: {
    width: 2,
    height: 20,
    backgroundColor: colors.textSecondary,
    marginLeft: 5,
    marginBottom: 8,
  },
  emirateScroll: {
    marginTop: 8,
  },
  emirateChip: {
    backgroundColor: colors.highlight,
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    marginRight: 8,
  },
  emirateChipSelected: {
    backgroundColor: colors.primary,
  },
  emirateChipText: {
    fontSize: 14,
    color: colors.text,
    fontWeight: '500',
  },
  emirateChipTextSelected: {
    color: '#FFFFFF',
  },
  searchButton: {
    backgroundColor: colors.primary,
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 8,
  },
  searchButtonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
    marginRight: 8,
  },
  quickActions: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 12,
  },
  quickActionsGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  quickActionCard: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    flex: 1,
    marginHorizontal: 4,
    boxShadow: '0px 2px 8px rgba(0, 0, 0, 0.06)',
    elevation: 2,
  },
  quickActionText: {
    fontSize: 12,
    fontWeight: '600',
    color: colors.text,
    marginTop: 8,
    textAlign: 'center',
  },
  recentSection: {
    marginBottom: 20,
  },
  recentTrip: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
    boxShadow: '0px 2px 8px rgba(0, 0, 0, 0.06)',
    elevation: 2,
  },
  recentTripIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: colors.highlight,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  recentTripDetails: {
    flex: 1,
  },
  recentTripTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 4,
  },
  recentTripSubtitle: {
    fontSize: 14,
    color: colors.textSecondary,
  },
});
