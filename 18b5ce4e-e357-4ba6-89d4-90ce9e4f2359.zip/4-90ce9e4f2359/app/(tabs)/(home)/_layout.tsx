
import React from 'react';
import { Stack } from 'expo-router';
import { colors } from '@/styles/commonStyles';

export default function HomeLayout() {
  return (
    <Stack
      screenOptions={{
        headerStyle: {
          backgroundColor: colors.card,
        },
        headerTintColor: colors.primary,
        headerTitleStyle: {
          fontWeight: 'bold',
          color: colors.text,
        },
        headerShadowVisible: true,
      }}
    >
      <Stack.Screen 
        name="index" 
        options={{
          headerShown: true,
          title: "UAE Cab Share",
        }}
      />
      <Stack.Screen 
        name="ride-options" 
        options={{
          headerShown: true,
          title: "Choose Your Ride",
        }}
      />
      <Stack.Screen 
        name="ride-tracking" 
        options={{
          headerShown: true,
          title: "Your Ride",
        }}
      />
    </Stack>
  );
}
