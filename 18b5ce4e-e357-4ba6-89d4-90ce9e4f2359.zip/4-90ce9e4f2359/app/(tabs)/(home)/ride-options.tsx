
import React, { useState } from "react";
import { Stack, useLocalSearchParams, useRouter } from "expo-router";
import {
  ScrollView,
  Pressable,
  StyleSheet,
  View,
  Text,
  Platform,
} from "react-native";
import { IconSymbol } from "@/components/IconSymbol";
import { SafeAreaView } from "react-native-safe-area-context";
import { colors } from "@/styles/commonStyles";

interface RideOption {
  id: string;
  type: string;
  description: string;
  capacity: number;
  estimatedTime: string;
  price: number;
  icon: string;
}

const RIDE_OPTIONS: RideOption[] = [
  {
    id: "1",
    type: "Economy Share",
    description: "Share with up to 3 passengers",
    capacity: 4,
    estimatedTime: "5-10 min",
    price: 25,
    icon: "car.fill",
  },
  {
    id: "2",
    type: "Comfort Share",
    description: "More spacious, share with 2 passengers",
    capacity: 3,
    estimatedTime: "5-10 min",
    price: 35,
    icon: "car.2.fill",
  },
  {
    id: "3",
    type: "Premium",
    description: "Luxury ride, no sharing",
    capacity: 1,
    estimatedTime: "3-8 min",
    price: 55,
    icon: "sparkles",
  },
  {
    id: "4",
    type: "XL Share",
    description: "Large vehicle for groups",
    capacity: 6,
    estimatedTime: "8-15 min",
    price: 45,
    icon: "bus.fill",
  },
];

export default function RideOptionsScreen() {
  const params = useLocalSearchParams();
  const router = useRouter();
  const [selectedRide, setSelectedRide] = useState<string | null>(null);

  const pickup = params.pickup as string;
  const dropoff = params.dropoff as string;
  const emirate = params.emirate as string;

  const handleConfirmRide = () => {
    if (!selectedRide) return;
    
    const ride = RIDE_OPTIONS.find(r => r.id === selectedRide);
    console.log("Confirming ride:", ride);
    
    router.push({
      pathname: "/(tabs)/(home)/ride-tracking",
      params: {
        pickup,
        dropoff,
        emirate,
        rideType: ride?.type,
        price: ride?.price.toString(),
      }
    });
  };

  return (
    <>
      <Stack.Screen
        options={{
          title: "Choose Your Ride",
          headerBackTitle: "Back",
        }}
      />
      <SafeAreaView style={styles.safeArea} edges={['bottom']}>
        <ScrollView 
          style={styles.container}
          contentContainerStyle={styles.contentContainer}
          showsVerticalScrollIndicator={false}
        >
          {/* Trip Details */}
          <View style={styles.tripDetails}>
            <View style={styles.tripRoute}>
              <View style={styles.routeIconContainer}>
                <View style={styles.routeDot} />
                <View style={styles.routeLine} />
                <View style={styles.routeSquare} />
              </View>
              <View style={styles.routeDetails}>
                <View style={styles.routeItem}>
                  <Text style={styles.routeLabel}>Pickup</Text>
                  <Text style={styles.routeText}>{pickup}</Text>
                </View>
                <View style={styles.routeItem}>
                  <Text style={styles.routeLabel}>Drop-off</Text>
                  <Text style={styles.routeText}>{dropoff}</Text>
                </View>
              </View>
            </View>
            {emirate && (
              <View style={styles.emirateTag}>
                <IconSymbol name="location.fill" size={16} color={colors.primary} />
                <Text style={styles.emirateText}>{emirate}</Text>
              </View>
            )}
          </View>

          {/* Ride Options */}
          <View style={styles.optionsSection}>
            <Text style={styles.sectionTitle}>Available Rides</Text>
            {RIDE_OPTIONS.map((option) => (
              <Pressable
                key={option.id}
                style={[
                  styles.rideOption,
                  selectedRide === option.id && styles.rideOptionSelected,
                ]}
                onPress={() => setSelectedRide(option.id)}
              >
                <View style={styles.rideIconContainer}>
                  <IconSymbol 
                    name={option.icon as any} 
                    size={32} 
                    color={selectedRide === option.id ? colors.primary : colors.textSecondary} 
                  />
                </View>
                <View style={styles.rideDetails}>
                  <Text style={styles.rideType}>{option.type}</Text>
                  <Text style={styles.rideDescription}>{option.description}</Text>
                  <View style={styles.rideInfo}>
                    <View style={styles.rideInfoItem}>
                      <IconSymbol name="person.fill" size={14} color={colors.textSecondary} />
                      <Text style={styles.rideInfoText}>{option.capacity}</Text>
                    </View>
                    <View style={styles.rideInfoItem}>
                      <IconSymbol name="clock.fill" size={14} color={colors.textSecondary} />
                      <Text style={styles.rideInfoText}>{option.estimatedTime}</Text>
                    </View>
                  </View>
                </View>
                <View style={styles.ridePriceContainer}>
                  <Text style={styles.ridePrice}>AED {option.price}</Text>
                  {selectedRide === option.id && (
                    <View style={styles.selectedBadge}>
                      <IconSymbol name="checkmark" size={16} color="#FFFFFF" />
                    </View>
                  )}
                </View>
              </Pressable>
            ))}
          </View>

          {/* Payment Info */}
          <View style={styles.paymentInfo}>
            <View style={styles.paymentRow}>
              <IconSymbol name="creditcard.fill" size={20} color={colors.primary} />
              <Text style={styles.paymentText}>Payment Method</Text>
            </View>
            <Text style={styles.paymentMethod}>Visa •••• 4242</Text>
          </View>
        </ScrollView>

        {/* Confirm Button */}
        {selectedRide && (
          <View style={styles.confirmContainer}>
            <Pressable 
              style={styles.confirmButton}
              onPress={handleConfirmRide}
            >
              <Text style={styles.confirmButtonText}>Confirm Ride</Text>
              <IconSymbol name="arrow.right" size={20} color="#FFFFFF" />
            </Pressable>
          </View>
        )}
      </SafeAreaView>
    </>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.background,
  },
  container: {
    flex: 1,
  },
  contentContainer: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 100,
  },
  tripDetails: {
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
    boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.08)',
    elevation: 4,
  },
  tripRoute: {
    flexDirection: 'row',
  },
  routeIconContainer: {
    alignItems: 'center',
    marginRight: 16,
  },
  routeDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: colors.primary,
  },
  routeLine: {
    width: 2,
    height: 40,
    backgroundColor: colors.textSecondary,
    marginVertical: 4,
  },
  routeSquare: {
    width: 12,
    height: 12,
    backgroundColor: colors.accent,
  },
  routeDetails: {
    flex: 1,
  },
  routeItem: {
    marginBottom: 20,
  },
  routeLabel: {
    fontSize: 12,
    fontWeight: '600',
    color: colors.textSecondary,
    marginBottom: 4,
    textTransform: 'uppercase',
  },
  routeText: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
  },
  emirateTag: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.highlight,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    alignSelf: 'flex-start',
    marginTop: 12,
  },
  emirateText: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.primary,
    marginLeft: 6,
  },
  optionsSection: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 16,
  },
  rideOption: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
    borderWidth: 2,
    borderColor: 'transparent',
    boxShadow: '0px 2px 8px rgba(0, 0, 0, 0.06)',
    elevation: 2,
  },
  rideOptionSelected: {
    borderColor: colors.primary,
    backgroundColor: colors.highlight,
  },
  rideIconContainer: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: colors.highlight,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  rideDetails: {
    flex: 1,
  },
  rideType: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 4,
  },
  rideDescription: {
    fontSize: 14,
    color: colors.textSecondary,
    marginBottom: 8,
  },
  rideInfo: {
    flexDirection: 'row',
    gap: 16,
  },
  rideInfoItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  rideInfoText: {
    fontSize: 12,
    color: colors.textSecondary,
  },
  ridePriceContainer: {
    alignItems: 'flex-end',
  },
  ridePrice: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.primary,
  },
  selectedBadge: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 8,
  },
  paymentInfo: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    boxShadow: '0px 2px 8px rgba(0, 0, 0, 0.06)',
    elevation: 2,
  },
  paymentRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  paymentText: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.textSecondary,
    marginLeft: 8,
  },
  paymentMethod: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
    marginLeft: 28,
  },
  confirmContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: colors.card,
    padding: 20,
    borderTopWidth: 1,
    borderTopColor: colors.highlight,
    boxShadow: '0px -4px 12px rgba(0, 0, 0, 0.08)',
    elevation: 8,
  },
  confirmButton: {
    backgroundColor: colors.primary,
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  confirmButtonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
    marginRight: 8,
  },
});
