
import React, { useState, useEffect } from "react";
import { Stack, useLocalSearchParams, useRouter } from "expo-router";
import {
  ScrollView,
  Pressable,
  StyleSheet,
  View,
  Text,
  Platform,
  Alert,
} from "react-native";
import { IconSymbol } from "@/components/IconSymbol";
import { SafeAreaView } from "react-native-safe-area-context";
import { colors } from "@/styles/commonStyles";

type RideStatus = 'searching' | 'driver-assigned' | 'arriving' | 'in-progress' | 'completed';

export default function RideTrackingScreen() {
  const params = useLocalSearchParams();
  const router = useRouter();
  const [rideStatus, setRideStatus] = useState<RideStatus>('searching');
  const [estimatedArrival, setEstimatedArrival] = useState(5);

  const pickup = params.pickup as string;
  const dropoff = params.dropoff as string;
  const rideType = params.rideType as string;
  const price = params.price as string;

  useEffect(() => {
    // Simulate ride status progression
    const timer1 = setTimeout(() => setRideStatus('driver-assigned'), 3000);
    const timer2 = setTimeout(() => setRideStatus('arriving'), 6000);
    
    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
    };
  }, []);

  useEffect(() => {
    // Simulate countdown
    if (rideStatus === 'arriving' && estimatedArrival > 0) {
      const timer = setInterval(() => {
        setEstimatedArrival(prev => Math.max(0, prev - 1));
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [rideStatus, estimatedArrival]);

  const handleCancelRide = () => {
    Alert.alert(
      "Cancel Ride",
      "Are you sure you want to cancel this ride?",
      [
        { text: "No", style: "cancel" },
        { 
          text: "Yes, Cancel", 
          style: "destructive",
          onPress: () => router.back()
        }
      ]
    );
  };

  const handleContactDriver = () => {
    Alert.alert("Contact Driver", "Calling driver...");
  };

  const getStatusInfo = () => {
    switch (rideStatus) {
      case 'searching':
        return {
          title: 'Finding Your Ride',
          subtitle: 'Searching for nearby drivers...',
          icon: 'magnifyingglass',
          color: colors.accent,
        };
      case 'driver-assigned':
        return {
          title: 'Driver Assigned',
          subtitle: 'Your driver is on the way',
          icon: 'checkmark.circle.fill',
          color: colors.primary,
        };
      case 'arriving':
        return {
          title: 'Driver Arriving',
          subtitle: `Arriving in ${estimatedArrival} minutes`,
          icon: 'car.fill',
          color: colors.primary,
        };
      case 'in-progress':
        return {
          title: 'Trip in Progress',
          subtitle: 'Enjoy your ride',
          icon: 'location.fill',
          color: colors.accent,
        };
      case 'completed':
        return {
          title: 'Trip Completed',
          subtitle: 'Thank you for riding with us',
          icon: 'checkmark.circle.fill',
          color: colors.primary,
        };
    }
  };

  const statusInfo = getStatusInfo();

  return (
    <>
      <Stack.Screen
        options={{
          title: "Your Ride",
          headerBackTitle: "Back",
        }}
      />
      <SafeAreaView style={styles.safeArea} edges={['bottom']}>
        <ScrollView 
          style={styles.container}
          contentContainerStyle={styles.contentContainer}
          showsVerticalScrollIndicator={false}
        >
          {/* Status Card */}
          <View style={styles.statusCard}>
            <View style={[styles.statusIcon, { backgroundColor: statusInfo.color + '20' }]}>
              <IconSymbol name={statusInfo.icon as any} size={48} color={statusInfo.color} />
            </View>
            <Text style={styles.statusTitle}>{statusInfo.title}</Text>
            <Text style={styles.statusSubtitle}>{statusInfo.subtitle}</Text>
          </View>

          {/* Map Placeholder */}
          <View style={styles.mapPlaceholder}>
            <IconSymbol name="map.fill" size={60} color={colors.primary} />
            <Text style={styles.mapPlaceholderText}>Live Tracking</Text>
            <Text style={styles.mapPlaceholderSubtext}>
              react-native-maps not supported
            </Text>
          </View>

          {/* Driver Info (shown after driver assigned) */}
          {rideStatus !== 'searching' && (
            <View style={styles.driverCard}>
              <View style={styles.driverAvatar}>
                <IconSymbol name="person.fill" size={32} color={colors.primary} />
              </View>
              <View style={styles.driverInfo}>
                <Text style={styles.driverName}>Ahmed Al-Mansoori</Text>
                <View style={styles.driverRating}>
                  <IconSymbol name="star.fill" size={16} color={colors.accent} />
                  <Text style={styles.ratingText}>4.9</Text>
                  <Text style={styles.ratingCount}>(234 trips)</Text>
                </View>
                <Text style={styles.carInfo}>Toyota Camry • ABC 1234</Text>
              </View>
              <Pressable 
                style={styles.contactButton}
                onPress={handleContactDriver}
              >
                <IconSymbol name="phone.fill" size={24} color="#FFFFFF" />
              </Pressable>
            </View>
          )}

          {/* Trip Details */}
          <View style={styles.tripCard}>
            <Text style={styles.cardTitle}>Trip Details</Text>
            
            <View style={styles.tripRoute}>
              <View style={styles.routeIconContainer}>
                <View style={styles.routeDot} />
                <View style={styles.routeLine} />
                <View style={styles.routeSquare} />
              </View>
              <View style={styles.routeDetails}>
                <View style={styles.routeItem}>
                  <Text style={styles.routeLabel}>Pickup</Text>
                  <Text style={styles.routeText}>{pickup}</Text>
                </View>
                <View style={styles.routeItem}>
                  <Text style={styles.routeLabel}>Drop-off</Text>
                  <Text style={styles.routeText}>{dropoff}</Text>
                </View>
              </View>
            </View>

            <View style={styles.divider} />

            <View style={styles.tripInfoRow}>
              <View style={styles.tripInfoItem}>
                <Text style={styles.tripInfoLabel}>Ride Type</Text>
                <Text style={styles.tripInfoValue}>{rideType}</Text>
              </View>
              <View style={styles.tripInfoItem}>
                <Text style={styles.tripInfoLabel}>Fare</Text>
                <Text style={styles.tripInfoValue}>AED {price}</Text>
              </View>
            </View>
          </View>

          {/* Share Ride Info */}
          <View style={styles.shareCard}>
            <IconSymbol name="person.2.fill" size={24} color={colors.primary} />
            <View style={styles.shareInfo}>
              <Text style={styles.shareTitle}>Sharing with 2 passengers</Text>
              <Text style={styles.shareSubtitle}>Save up to 40% on your fare</Text>
            </View>
          </View>

          {/* Safety Features */}
          <View style={styles.safetyCard}>
            <Text style={styles.cardTitle}>Safety Features</Text>
            <View style={styles.safetyFeatures}>
              <Pressable style={styles.safetyButton}>
                <IconSymbol name="shield.fill" size={20} color={colors.primary} />
                <Text style={styles.safetyButtonText}>Share Trip</Text>
              </Pressable>
              <Pressable style={styles.safetyButton}>
                <IconSymbol name="exclamationmark.triangle.fill" size={20} color={colors.accent} />
                <Text style={styles.safetyButtonText}>Emergency</Text>
              </Pressable>
            </View>
          </View>
        </ScrollView>

        {/* Cancel Button */}
        {rideStatus !== 'completed' && (
          <View style={styles.cancelContainer}>
            <Pressable 
              style={styles.cancelButton}
              onPress={handleCancelRide}
            >
              <Text style={styles.cancelButtonText}>Cancel Ride</Text>
            </Pressable>
          </View>
        )}
      </SafeAreaView>
    </>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.background,
  },
  container: {
    flex: 1,
  },
  contentContainer: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 100,
  },
  statusCard: {
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 32,
    alignItems: 'center',
    marginBottom: 20,
    boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.08)',
    elevation: 4,
  },
  statusIcon: {
    width: 96,
    height: 96,
    borderRadius: 48,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  statusTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 8,
  },
  statusSubtitle: {
    fontSize: 16,
    color: colors.textSecondary,
  },
  mapPlaceholder: {
    backgroundColor: colors.highlight,
    borderRadius: 16,
    height: 200,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
    borderWidth: 2,
    borderColor: colors.primary,
    borderStyle: 'dashed',
  },
  mapPlaceholderText: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
    marginTop: 12,
  },
  mapPlaceholderSubtext: {
    fontSize: 12,
    color: colors.textSecondary,
    marginTop: 4,
  },
  driverCard: {
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
    boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.08)',
    elevation: 4,
  },
  driverAvatar: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: colors.highlight,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  driverInfo: {
    flex: 1,
  },
  driverName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 4,
  },
  driverRating: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  ratingText: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.text,
    marginLeft: 4,
  },
  ratingCount: {
    fontSize: 12,
    color: colors.textSecondary,
    marginLeft: 4,
  },
  carInfo: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  contactButton: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
  },
  tripCard: {
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
    boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.08)',
    elevation: 4,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 16,
  },
  tripRoute: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  routeIconContainer: {
    alignItems: 'center',
    marginRight: 16,
  },
  routeDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: colors.primary,
  },
  routeLine: {
    width: 2,
    height: 40,
    backgroundColor: colors.textSecondary,
    marginVertical: 4,
  },
  routeSquare: {
    width: 12,
    height: 12,
    backgroundColor: colors.accent,
  },
  routeDetails: {
    flex: 1,
  },
  routeItem: {
    marginBottom: 20,
  },
  routeLabel: {
    fontSize: 12,
    fontWeight: '600',
    color: colors.textSecondary,
    marginBottom: 4,
    textTransform: 'uppercase',
  },
  routeText: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.text,
  },
  divider: {
    height: 1,
    backgroundColor: colors.highlight,
    marginVertical: 16,
  },
  tripInfoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  tripInfoItem: {
    flex: 1,
  },
  tripInfoLabel: {
    fontSize: 12,
    fontWeight: '600',
    color: colors.textSecondary,
    marginBottom: 4,
    textTransform: 'uppercase',
  },
  tripInfoValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.text,
  },
  shareCard: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
    boxShadow: '0px 2px 8px rgba(0, 0, 0, 0.06)',
    elevation: 2,
  },
  shareInfo: {
    flex: 1,
    marginLeft: 12,
  },
  shareTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 4,
  },
  shareSubtitle: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  safetyCard: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
    boxShadow: '0px 2px 8px rgba(0, 0, 0, 0.06)',
    elevation: 2,
  },
  safetyFeatures: {
    flexDirection: 'row',
    gap: 12,
  },
  safetyButton: {
    flex: 1,
    backgroundColor: colors.highlight,
    borderRadius: 8,
    padding: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  safetyButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.text,
  },
  cancelContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: colors.card,
    padding: 20,
    borderTopWidth: 1,
    borderTopColor: colors.highlight,
    boxShadow: '0px -4px 12px rgba(0, 0, 0, 0.08)',
    elevation: 8,
  },
  cancelButton: {
    backgroundColor: colors.secondary,
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  cancelButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
